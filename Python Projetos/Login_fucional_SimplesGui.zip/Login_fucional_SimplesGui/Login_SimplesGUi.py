                                    # **********************************************************************
import tkinter as tk   # <----------------- # Ínicio do código com a importação da biblioteca tk (Tkinter)   
                                    # **********************************************************************
# Primeira janela do GUI
contas = []

janela = tk.Tk()
janela.title("Primeiro Login Simples - GUI")
janela.geometry('400x300')

tk.Label(janela, text="usuário").pack()
usuario_entry = tk.Entry(janela)
usuario_entry.pack()

tk.Label(janela, text="senha").pack()
senha_entry = tk.Entry(janela, show="*")
senha_entry.pack()

mensagem_label = tk.Label(janela)
mensagem_label.pack()

def criar():
    usuario = usuario_entry.get()
    senha = senha_entry.get()
    contas.append((usuario, senha))
    mensagem_label['text'] = "Conta criada!"

def login():
    usuario = usuario_entry.get()
    senha = senha_entry.get()
    if (usuario, senha) in contas:
        mensagem_label['text'] = "Logado com sucesso!"
    else:
        mensagem_label['text'] = "Conta inválida ou não existente!"

tk.Button(janela, text="Criar", command="criar").pack()

tk.Button(janela, text="Login", command="login").pack()

mensagem_label = tk.Label(janela)

janela.mainloop()